package org.example;

import junit.framework.TestCase;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PayByCreditCardTest extends TestCase {

    @Test
    public void testIsMaestroCard()
    {
        String k="0012345678901234";
        String res="1";
        assertEquals(PayByCreditCard.isMaestroCard(k),Boolean.getBoolean(res));
    }
 @Test
    public void testIsVisaMasterCard() {
     String k="5412751234123456";
     String res="1";
     assertEquals(PayByCreditCard.isVisaMasterCard(k),Boolean.getBoolean(res));
    }
}