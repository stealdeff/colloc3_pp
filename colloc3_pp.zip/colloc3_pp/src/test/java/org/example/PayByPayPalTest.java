package org.example;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class PayByPayPalTest
{

    @Test
    public void testIsEmail()
    {
        String k="k990!!!";
        String res=null;
        assertEquals(PayByPayPal.isEmail(k),Boolean.getBoolean(res));

    }
    @Test
    public void testIsPassword()
    {
        String p="LoL90049004";
        String res="1";
        assertEquals(PayByPayPal.isEmail(p),Boolean.getBoolean(res));
    }
}